---
name: etchasketch-housing-archive
description: Pi mini-project Etch A Sketch housing — CAD source/STEP/renders archived as a zip in memory/archives; repo keeps only the 3 final STLs
metadata:
  node_type: memory
  type: project
  originSessionId: 59003435-87d6-4565-a123-de488e51d507
  modified: 2026-11-12T02:24:41.543Z
---

The 3D-printed "thick Etch A Sketch" housing for the Pi mini-project (Raspberry Pi 5 in a 52Pi C-0048 case, Waveshare 7" HDMI LCD (H), 2× KY-040) was finalized 2026-11-11.

The repo folder `Pi Mini Project/Housing/` keeps ONLY the final STLs being printed: `front_shell.stl`, `back_cover.stl`, `knobs_x2.stl` (all untracked, not committed). Everything else is in `memory/archives/etchasketch_housing_2026-11-11.zip` (35 files, verified):
- CadQuery source `etchasketch_housing.py`, plus `interaction_views.py`, `verify_fit.py`, `render_fit.py`, `show_encoder_assembly.py`
- STEP files, the fit-check STLs, `parts/` reference models, the Pi 5 drawing PDF
- README, `verification.json`, renders

To rebuild, unzip the archive somewhere outside the repo. It needs CadQuery 2.8, trimesh, pyrender and Pillow; the old scratchpad venv is session-only.

Final design, compressed:
- **Size:** 252.5×140.3 mm outline (bed 256), 47 mm deep. The screen (17 mm) stacks on top of the Pi (25 mm).
- **Walls and corners:** R7.5 outer corners. Side walls 2 mm; front wall and lid 2.5 mm.
- **HDMI space:** 57 mm on the left. Knobs at x=±72, symmetric about the screen.
- **Encoders:** both rotated 180°. Each has a continuous 20.5×2 mm slotted rail for hot-pushed M2.5 screws, plus a loose guide pocket (13.1 mm) around the encoder body.
- **Knob bore:** 6.254 / 4.754 mm (0.005" clearance per side), with R0.6 corner cutouts at the flat.
- **Lid screws:** 4 hot-pushed M3: top-left, bottom-left, bottom-middle, bottom-right. The screwless top-right corner is held by a snap arm hooking into a right-wall recess.
- **Pi outline on the lid:** walls 4 mm tall, pocket 89.3×57.1 mm (0.4 clearance per side). Gaps: 22 mm SD (centred), 48 mm HDMI/power edge from the SD corner, and the USB end open except 15 mm of wall at the HDMI corner.
- **Cable exit:** notch in the top wall (away from the user).

GPT also edited this design while Claude was rate-limited. The user prefers very short replies and fast turnaround.
